//
//  Conditionals_ChallengeApp.swift
//  Conditionals Challenge
//
//  Created by Tom Bredemeier on 9/15/21.
//

import SwiftUI

@main
struct Conditionals_ChallengeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
